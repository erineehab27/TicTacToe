# Game Instructions

- press 'g' to change gamemode (pvp or ai)
- press '0' to change ai level to 0 (random)
- press '1' to change ai level to 1 (impossible)
- press 'r' to restart the game


